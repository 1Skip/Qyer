<?php

function main_handler($event, $context)
{
  // echo __DIR__ . DIRECTORY_SEPARATOR . 'tcb-admin-php' . DIRECTORY_SEPARATOR . 'autoload.php' . PHP_EOL;
  require_once __DIR__ . DIRECTORY_SEPARATOR . 'tcb-admin-php' . DIRECTORY_SEPARATOR . 'autoload.php';
  // function test -> callFunction
  $tcb = new TencentCloudBase\TCB(array("secretId" => "AKIDrWNM7caVI6g5K7scsuufDai9OM7dnbhZ", "secretKey" => "VByVxdONDoDOPfmmY7TbT6YrvnQsDPRD"));

  print_r($tcb);

  return 'ok';
  // $functions = $tcb->getFunctions();
  // $result = $functions->callFunction([
  //   "name" => "test",
  //   "data" => array('a' => 1)
  // ]);
  // print_r($result);

  // // storage test
  // // getTempFileURL
  // $storage = $tcb->getStorage();
  // $result = $storage->getTempFileURL([
  //   "fileList" => [
  //     ["fileID" => "cloud://jimmytest-088bef.jimmytest-088bef-1251059088/a|b.jpeg", "maxAge" => 100000] // 预发
  //   ]
  // ]);

  // $fileList = $result["fileList"];
  // print_r($fileList);

  // 
}

main_handler(null, null);
