<?php

require_once __DIR__ . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';
// echo __DIR__ . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';

// spl_autoload_register(function ($class_name) {
//   $clsName = str_replace("\\", DIRECTORY_SEPARATOR, $class_name);
//   $clsStrs = explode(DIRECTORY_SEPARATOR, $clsName);
//   $clsNewName = join(DIRECTORY_SEPARATOR, array_slice($clsStrs, 1));
//   echo __DIR__ . DIRECTORY_SEPARATOR . "src" . DIRECTORY_SEPARATOR . $clsNewName . '.php' . PHP_EOL;
//   if (is_file(__DIR__ . DIRECTORY_SEPARATOR . "src" . DIRECTORY_SEPARATOR . $clsNewName . '.php')) {
//     echo 'test suc' . PHP_EOL;
//     require_once(__DIR__ . DIRECTORY_SEPARATOR . "src" . DIRECTORY_SEPARATOR . $clsNewName . '.php');
//   }
// });
// spl_autoload_register(function ($class_name) {
//   $clsName = str_replace("\\", DIRECTORY_SEPARATOR, $class_name);
//   $clsStrs = explode(DIRECTORY_SEPARATOR, $clsName);
//   $clsNewName = join(DIRECTORY_SEPARATOR, array_slice($clsStrs, 1));

//   echo __DIR__ . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . $clsNewName . '.php' . PHP_EOL;
//   if (is_file(__DIR__ . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . $clsNewName . '.php')) {
//     require_once(__DIR__ . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . $clsNewName . '.php');
//   }
// });
